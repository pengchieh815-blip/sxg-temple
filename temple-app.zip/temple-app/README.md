# 八里無極受玄宮 活動登記系統

## 部署前設定

### 1. 修改管理者帳號
開啟 `src/App.jsx`，找到第 19 行：
```js
const ADMIN_EMAILS = ["your-admin@gmail.com"];
```
換成您的 Gmail，例如：
```js
const ADMIN_EMAILS = ["temple@gmail.com"];
```

### 2. Firebase 安全規則
前往 Firebase Console → Firestore Database → 規則，貼上：
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /registrations/{doc} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }
}
```

### 3. 開啟 Firebase Google 登入
Firebase Console → Authentication → Sign-in method → Google → 啟用

---

## 部署到 Vercel

1. 前往 https://vercel.com 用 Google 帳號登入
2. 點「Add New Project」→「Upload」
3. 上傳整個資料夾（temple-app）
4. 設定：
   - Framework: Create React App
   - Build Command: npm run build
   - Output Directory: build
5. 點「Deploy」
6. 幾分鐘後得到網址，例如：https://sxg-temple.vercel.app

---

## 本地測試（需要安裝 Node.js）
```
npm install
npm start
```
